<script setup lang="ts"></script>

<template>
  <div class="spacer pb-0">
    <v-container class="maxWidth">
      <v-row class="justify-center">
        <v-col md="6" cols="12">
          <div class="text-center">
            <h6 class="text-subtitle-1 text-primary">Mantis nailed it!</h6>
            <h2 class="text-h2 mt-2 mb-4">Why Mantis?</h2>
            <p class="text-h6 mb-0">
              Customize everything with the Mantis Vue3 Typescript Dashboard Template built with latest Vuetify component library
            </p>
          </div>
        </v-col>
        <v-col md="12" cols="12"></v-col>
        <v-col lg="4" sm="6" cols="12" data-aos="fade-up" data-aos-duration="800">
          <v-card variant="outlined" class="pa-5 bg-surface text-start">
            <v-avatar size="65" variant="flat">
              <img src="@/assets/images/landing/img-feature1.svg" width="48" alt="feature" />
            </v-avatar>
            <h3 class="text-h5 mt-4">Professional Design</h3>
            <p class="mt-2 mb-0 text-h6 text-lightText">
              Mantis has fully professional grade user interface for any kind of backend project.
            </p>
          </v-card>
        </v-col>
        <v-col lg="4" sm="6" cols="12" data-aos="fade-up" data-aos-duration="800">
          <v-card variant="outlined" class="pa-5 bg-surface text-start">
            <v-avatar size="65" variant="flat">
              <img src="@/assets/images/landing/img-feature2.svg" width="48" alt="feature" />
            </v-avatar>
            <h3 class="text-h5 mt-4">Flexible Solution</h3>
            <p class="mt-2 mb-0 text-h6 text-lightText">Highly flexible to work around using Mantis Vue Template.</p>
          </v-card>
        </v-col>
        <v-col lg="4" sm="6" cols="12" data-aos="fade-up" data-aos-duration="800">
          <v-card variant="outlined" class="pa-5 bg-surface text-start">
            <v-avatar size="65" variant="flat">
              <img src="@/assets/images/landing/img-feature3.svg" width="48" alt="feature" />
            </v-avatar>
            <h3 class="text-h5 mt-4">Effective Documentation</h3>
            <p class="mt-2 mb-0 text-h6 text-lightText">Need help? Check out the detailed Documentation guide.</p>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

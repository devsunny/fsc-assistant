<script setup lang="ts"></script>

<template>
  <v-text-field color="primary"><slot /></v-text-field>
</template>

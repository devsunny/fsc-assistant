<template>
  <v-card variant="outlined" class="bg-surface">
    <v-card-text>
      <v-label class="mb-2">Have a Promo Code?</v-label>
      <div class="d-flex ga-4">
        <v-text-field single-line hide-details variant="outlined" color="primary" placeholder="Enter promo code"></v-text-field>
        <v-btn color="primary" variant="flat" style="height: 42px">Apply</v-btn>
      </div>
    </v-card-text>
  </v-card>
</template>
